SDCard.copy_from_mod_to_sd_card("st_dxrcruise.rel", "private/wii/app/RSBE/pf/module")
SDCard.copy_from_mod_to_sd_card("STGDXRCRUISE.pac", "private/wii/app/RSBE/pf/stage/melee")