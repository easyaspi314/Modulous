import('System')
import('ModulousMM')
import('ModulousLib')
import('ModulousLib.BrawlEX')
import = function() end
print('Lua API init')
print = LuaConsole.Write